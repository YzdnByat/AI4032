import numpy as np

def segment_fft(signal, segment_size, overlap_size, Fs):


    num_segments = (len(signal) - segment_size) // overlap_size + 1  
    fft_results = []  

    for i in range(num_segments):
       
        start = i * overlap_size
        end = start + segment_size
        segment = signal[start:end]
        
        
        fft_values = np.fft.fft(segment)
        freqs = np.fft.fftfreq(len(segment), 1/Fs)
        fft_magnitude = np.abs(fft_values[:len(segment)//2])  
        fft_results.append(fft_magnitude)

    return np.array(fft_results)  