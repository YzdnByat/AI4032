import numpy as np

def features(signal):
    
    mean_value = np.mean(signal) 
    std_value = np.std(signal) 
    rms_value = np.sqrt(np.mean(signal**2))  
    
    return mean_value, std_value, rms_value
