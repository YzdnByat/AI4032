def fft(signal, Fs):
    import numpy as np
    import matplotlib.pyplot as plt

    
    N = len(signal)  
    fft_values = np.fft.fft(signal)  
    freqs = np.fft.fftfreq(N, 1/Fs)  
    
    fft_magnitude = np.abs(fft_values[:N//2])
    freqs = freqs[:N//2]

    return freqs, fft_magnitude