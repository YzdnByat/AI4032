import pandas as pd
import matplotlib.pyplot as plt
from scipy import io
import numpy as np

#نحوه خواندن دیتاست
data_set = "112.mat"
data = io.loadmat(data_set)
#انتخاب یک سری از دیتا ها
signal = data["X112_FE_time"].flatten()
#نمایش دیتای انتخاب شده
print(f"signal: ",signal)
#نمایش دیتا روی نمودار با استفاده از متپلات
freq = 48000
time = np.arange(len(signal)) / freq

plt.figure(figsize = (10, 5))
plt.plot(time[:], signal[:], label="X112_FE_time")
plt.xlabel("Time")
plt.ylabel("Data")
plt.legend()
plt.grid(True)
plt.show()


start_time = int(2 * freq)
end_time = int(2.01 * freq)

plt.figure(figsize = (10, 5))
plt.plot(time[start_time:end_time], signal[start_time:end_time], label="X112_FE_time")
plt.xlabel("Time")
plt.ylabel("Data")
plt.legend()
plt.grid(True)
plt.show()

from Fourier import fft

freqs, fft_magnitude = fft(signal, freq)

plt.figure(figsize=(10, 5))
plt.plot(freqs, fft_magnitude, label="FFT Magnitude")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Amplitude")
plt.title("Frequency Spectrum of Signal")
plt.grid(True)
plt.legend()
plt.show()

dominant_freq = freqs[np.argmax(fft_magnitude)]
print(f"dominant frequency: ", dominant_freq)

from segment import segment_fft

segment_size = 128
overlap_size = 64

fft_segments = segment_fft(signal, segment_size, overlap_size, freq)

plt.figure(figsize=(10, 5))
plt.plot(np.fft.fftfreq(segment_size, 1/freq)[:segment_size//2], fft_segments[0], label="FFT of Segment 1")
plt.xlabel("Frequency")
plt.grid(True)
plt.legend()
plt.show()

df = pd.DataFrame(fft_segments)

for i in range(10):
    plt.plot(df.iloc[i * 3], label=f'Segment {i}')

plt.title("Selected Signal Segments")
plt.xlabel("Sample Index")
plt.ylabel("Amplitude")
plt.legend()
plt.grid(True)
plt.show()

from feature_extraction import features

features = [features(segment) for segment in df.values]
df_features = pd.DataFrame(features, columns=['Mean', 'Std Dev', 'RMS'])

mean_value, std_value, rms_value = df_features.iloc[0] 


print(f"Mean: {mean_value}")
print(f"Standard Deviation: {std_value}")
print(f"RMS: {rms_value}")

df_features.to_csv("features.csv", index=False)
