from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D
import numpy as np

iris = load_iris()

df = pd.DataFrame(data=iris.data, columns=iris.feature_names)

df['species'] = iris.target
df['species'] = df['species'].map({0: 'setosa', 1: 'versicolor', 2: 'virginica'})

train_df, test_df = train_test_split(df, test_size=0.2, random_state=42)

train_df = train_df.copy()
test_df = test_df.copy()
train_df['dataset'] = 'training'
test_df['dataset'] = 'testing'

merged_df = pd.concat([train_df, test_df]).reset_index(drop=True)

print("Merged DataFrame:")
print(merged_df.head())

feature_x = "sepal length (cm)"
feature_y = "sepal width (cm)"

plt.figure(figsize=(8, 6))
sns.scatterplot(x=merged_df[feature_x], y=merged_df[feature_y], hue=merged_df['species'], style=merged_df['dataset'], palette="viridis")
plt.xlabel(feature_x)
plt.ylabel(feature_y)
plt.title("2D Scatter Plot")
plt.legend(title="Dataset")
plt.show()


feature_x = "sepal length (cm)"
feature_y = "sepal width (cm)"
feature_z = "petal length (cm)"

fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')

for species in merged_df['species'].unique():
    subset = merged_df[merged_df['species'] == species]
    ax.scatter(subset[feature_x], subset[feature_y], subset[feature_z], label=species)

ax.set_xlabel(feature_x)
ax.set_ylabel(feature_y)
ax.set_zlabel(feature_z)
ax.set_title("3D Scatter Plot")
ax.legend()
plt.show()


numeric_df = df.drop(columns=['species'], errors='ignore')
plt.figure(figsize=(8, 6))
sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Heatmap")
plt.show()


features = df.columns[:-1]  
for feature in features:
    plt.figure(figsize=(8, 5))
    sns.kdeplot(train_df[feature], label="Training Data", fill=True, alpha=0.6)
    sns.kdeplot(test_df[feature], label="Testing Data", fill=True, alpha=0.6)
    plt.xlabel(feature)
    plt.ylabel("Density")
    plt.title(f"Probability Density of {feature} (Training vs Testing)")
    plt.legend()
    plt.show()


feature_to_bin = "sepal length (cm)"
bin_labels = ["Short", "Medium", "Tall"]
df["sepal_length_category"] = pd.qcut(df[feature_to_bin], q=3, labels=bin_labels)

print("\nDataFrame with Categorical Feature:")
print(df[[feature_to_bin, "sepal_length_category"]])


setosa_stats = df[df['species'] == 'setosa'].describe()
print("\nStatistical Summary for Setosa Class:")
print(setosa_stats)